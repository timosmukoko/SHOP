<?php include('include/home/header.php'); ?>
	
	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>About Us</h2>
						<address>
	    					<p>TMS Online Shop</p>
							<p>Moylish Park</p>
							<p>Mobile: 061 000000</p>
							<p>Fax:</p>
							<p>Email: k00203438@student.lit.ie</p>
	    				</address>
					</div><!--/login form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
	
	
<?php include('include/home/footer.php'); ?>